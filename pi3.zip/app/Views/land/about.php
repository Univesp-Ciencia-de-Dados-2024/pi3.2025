<section>

	<h1>About Page</h1>

	<p>If you would like to edit this page you will find it located at:</p>

	<pre><code>app/Views/land/about.php</code></pre>

	<p>The corresponding controller for this page can be found at:</p>

	<pre><code>app/Modules/Land/Controllers/About.php</code></pre>

</section>