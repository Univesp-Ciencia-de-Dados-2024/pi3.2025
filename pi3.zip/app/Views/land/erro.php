    <div class="confirmation-container">
        <h1>Ops, falha ao inserir seu cadastro!</h1>
        <p>Seu cadastro não foi inserido na base de dados. Tente novamente.</p>
        <button onclick="window.location.href='index.html'">Voltar para a Página Inicial</button>
    </div>
