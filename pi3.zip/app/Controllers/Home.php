<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        teste();
      //  return view('welcome_message');
    }
}
